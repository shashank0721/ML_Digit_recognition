# Digit-Recognition-
Digit Recognition with MNIST data set and open cv
